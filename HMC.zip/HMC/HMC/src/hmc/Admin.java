/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmc;

/**
 *
 * @author RGUKT
 */
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author RGUKT
 */
public class Admin {
    private JFrame f1;
    private JLabel label;
    private JTextField usrtextremove;
    private JButton hm,logoutbtn,addempbtn,rmempbtn;
    Admin(){
    
        f1=new JFrame("Admin");
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setBackground(Color.cyan);
        label = new JLabel("ADMIN",JLabel.CENTER);
	Font myFont=new Font("Bauhaus 93", Font.PLAIN, 60);
        label.setFont(myFont);
	label.setForeground(Color.DARK_GRAY);
        label.setBackground(Color.cyan);
	label.setBounds(01,01,1360,142);
        label.setOpaque(true);
	f1.add(label);
        
        //Image
        JLabel background=new JLabel(new ImageIcon("C:\\Users\\iiitbasar\\Desktop\\HMC\\HMC\\src\\hmc\\hall.jpg"));
        background.setBounds(-40,150,1400,768);
        background.setBackground(Color.white);
        background.setLayout(new FlowLayout());
        f1.add(background);
        
        
        
        //Buttons
        hm=new JButton("Home");
	hm.setBounds(200,200,200,35);
        hm.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
               f1.dispose();
               new HMC();
             }
        });
	hm.setBackground(Color.LIGHT_GRAY);
	Font my11=new Font("Serif", Font.BOLD, 20);
	hm.setFont(my11);
        f1.add(hm);
        
        JButton addbtn=new JButton("Add User");
	addbtn.setBounds(200,280,200,35);
        addbtn.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                f1.dispose();
                new Register();
             }
        });
	addbtn.setBackground(Color.LIGHT_GRAY);
	addbtn.setFont(my11);
        
        
        JButton rmbtn=new JButton("Remove User");
	rmbtn.setBounds(200,360,200,35);
        rmbtn.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                        f1.dispose();
                        new RemoveUser();
             }
        });
	rmbtn.setBackground(Color.LIGHT_GRAY);
	Font my111=new Font("Serif", Font.BOLD, 20);
	rmbtn.setFont(my111);
        
        addempbtn=new JButton("Add Employee");
	addempbtn.setBounds(200,440,200,35);
        addempbtn.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                f1.dispose();
                new AddEmployee();
             }
        });
	addempbtn.setBackground(Color.LIGHT_GRAY);
	addempbtn.setFont(my11);
        
        
        rmempbtn=new JButton("Remove Employee");
	rmempbtn.setBounds(200,520,200,35);
        rmempbtn.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                        f1.dispose();
                        new RemoveEmployee();
             }
        });
	rmempbtn.setBackground(Color.LIGHT_GRAY);
	rmempbtn.setFont(my111);
        
        
        logoutbtn=new JButton("Logout");
	logoutbtn.setBounds(200,600,200,35);
	       logoutbtn.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                f1.dispose();
                new Logged().remLogged();
                new HMC();
             }
        });
	logoutbtn.setBackground(Color.LIGHT_GRAY);
	logoutbtn.setFont(my11);
        f1.add(logoutbtn);
        
        f1.add(rmbtn);
        f1.add(addbtn);
        f1.add(addempbtn);
        f1.add(rmempbtn);
        f1.setSize(1380,750);
	f1.setBackground(Color.blue);
	f1.setLayout(null);
        f1.setVisible(true);
	f1.addWindowListener(new WindowAdapter(){
        @Override
	public void windowClosing(WindowEvent we){
		f1.dispose();}
        });
    }
    
        public static void main(String[] args) {
       new Admin();   
    }
    
}

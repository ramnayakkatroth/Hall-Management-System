/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmc;

/**
 *
 * @author RGUKT
 */
import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.sql.*;  

public class RemoveEmployee {
    private JLabel label;
    private JButton hm,backbtn;
    private JTextField usrtextremove;
    public RemoveEmployee()
    {
        JFrame f2=new JFrame("remove employee");
        f2.setBackground(Color.cyan);
        label = new JLabel("REMOVE EMPLOYEE",JLabel.CENTER);
        Font myFont=new Font("Bauhaus 93", Font.PLAIN, 60);
        label.setFont(myFont);
        label.setForeground(Color.DARK_GRAY);
        label.setBackground(Color.cyan);
        label.setBounds(01,01,1360,142);
        label.setOpaque(true);
        f2.add(label);

        hm=new JButton("Home");
        hm.setBounds(10,50,130,35);
        hm.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
               f2.dispose();
               new HMC();
             }
        });
        hm.setBackground(Color.LIGHT_GRAY);
        Font my11=new Font("Serif", Font.BOLD, 20);
        hm.setFont(my11);
        label.add(hm);


        Font f = new Font("Serif",Font.PLAIN,25);
        JLabel usrlabel = new JLabel("UserName:");
        usrlabel.setFont(f);
        usrlabel.setBounds(500,190, 220, 50);
        f2.add(usrlabel);

        usrtextremove = new JTextField();
        usrtextremove.setFont(f);
        usrtextremove.setBounds(630, 200, 200, 40);
        f2.add(usrtextremove);

        JButton   loginButton = new JButton("Remove");
        loginButton.setBounds(630, 250, 130, 35);
        loginButton.addActionListener( new ActionListener(){
        public void actionPerformed(ActionEvent e){
                        if(sqlValidateRemove())
                        {
                            if(remove()){
                                JOptionPane.showMessageDialog(null, "Employee Deleted");
                                f2.dispose();
                                new Admin();
                            }
                            else
                            {
                                JOptionPane.showMessageDialog(null, "OOPS! Detected problem in Deleting");
                                //f2.dispose();
                            }
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null, "Invalid UserName");
                        }


                 }
            });
            loginButton.setBackground(Color.LIGHT_GRAY);
            Font buttonFont=new Font("Serif", Font.BOLD, 20);
            loginButton.setFont(buttonFont);
            f2.add(loginButton);



            backbtn = new JButton("Back");
            backbtn.setBounds(1220, 50, 130, 35);
            backbtn.setFont(buttonFont);
            backbtn.addActionListener( new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    f2.dispose();
                    new Admin();
                 }
            });
            backbtn.setBackground(Color.LIGHT_GRAY);
            backbtn.setVisible(true);
            label.add(backbtn);

        f2.setBounds(0,0,1380,750);
        f2.setBackground(Color.blue);
        f2.setLayout(null);
        f2.setVisible(true);
        f2.addWindowListener(new WindowAdapter(){
        @Override
        public void windowClosing(WindowEvent we){
                f2.dispose();}
        });

    }
    
    boolean sqlValidateRemove()
    {
       String uname = usrtextremove.getText();
        
        try  
        {  
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/student", "root","");
            String sql="select * from empreg where username='"+uname+"'";
            PreparedStatement ps = con.prepareStatement(sql);  
            ResultSet rs = ps.executeQuery();  
            if (rs.next())   
            {  
                return true;  
            }
            else
            {
                return false;
            }
        }  
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return false;
    }
    
    boolean remove()
    {
        String uname = usrtextremove.getText();
        try  
        { 
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/student", "root","");
            String sql = "delete from empreg where username='"+uname+"'";
            PreparedStatement ps = con.prepareStatement(sql);
            int rs = ps.executeUpdate();
            if (rs>0)   
            {
                return true;
            }
            else
            {
                return false;
            }
        }  
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return false;
    }
    
    public static void main(String[] args)
    {
        new RemoveEmployee();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmc;

/**
 *
 * @author RGUKT
 */

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.util.Set;
public class HMC {

    /**
     * @param args the command line arguments
     */
    JFrame f1;
    JButton hm,std,emp,btnNewButton;
    JLabel labe;
    HMC(){
        f1=new JFrame("HMC");
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.setBackground(Color.cyan);
        labe = new JLabel("HALL MANAGEMENT CENTER",JLabel.CENTER);
	Font myFont=new Font("Bauhaus 93", Font.PLAIN, 60);
        labe.setFont(myFont);
	labe.setForeground(Color.DARK_GRAY);
        labe.setBackground(Color.cyan);
	labe.setBounds(01,01,1360,142);
        labe.setOpaque(true);
	f1.add(labe);
        // image button 
        
   
    ImageIcon ic2 = new ImageIcon("C:\\Users\\iiitbasar\\Downloads\\info.png");
    JButton btn2 = new JButton(ic2);
    btn2.setBounds(100,600,90,80);
    btn2.setOpaque(false);
    btn2.setBorderPainted(false);
    btn2.setContentAreaFilled(false);
    
    f1.add(btn2);
        btn2.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        System.out.println("Info clicked");
    }
});
        //Image
        JLabel background=new JLabel(new ImageIcon("C:\\Users\\iiitbasar\\Desktop\\HMC\\HMC\\src\\hmc\\hall.jpg"));
        background.setBounds(-40,150,1400,768);
        background.setBackground(Color.white);
        background.setLayout(new FlowLayout());
        f1.add(background);
        
        
        
        //Buttons
        hm=new JButton("Home");
        hm.setBackground(Color.red);
	hm.setBounds(1100,300,130,35);
        hm.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
               // LogIn i=new LogIn();
             }
        });
	hm.setBackground(Color.LIGHT_GRAY);
	Font my11=new Font("Serif", Font.BOLD, 20);
	hm.setFont(my11);
       
        
        std=new JButton("Student");
	std.setBounds(220,200,130,35);
	std.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String uname = new Logged().getId();
                if(uname.equals("NA"))
                {
                    f1.dispose();
                    new Login();
                }
                else if(uname.equals("messadmin"))
                {
                    JOptionPane.showMessageDialog(null, "MessManager is already logined");
                }
                else if(uname.equals("wardenadmin"))
                {
                    JOptionPane.showMessageDialog(null, "Warden is already logined");
                }
                else if(uname.equals("admin"))
                {
                    JOptionPane.showMessageDialog(null, "Admin is already logined");
                }
                else
                {
                    f1.dispose();
                    new Student_Page();
                }
             }
        });
	std.setBackground(Color.blue);
	Font my111=new Font("Serif", Font.BOLD, 20);
	std.setFont(my111);
        
        emp=new JButton("Employee");
	emp.setBounds(220,350,130,35);
	emp.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                String uname = new Logged().getId();
                if(uname.equals("NA")){
                    f1.dispose();
                    new EmpLogin();
                }
                else if(uname.equals("wardenadmin"))
                {
                    f1.dispose();
                    new Warden();
                }
                else if(uname.equals("messadmin"))
                {
                    f1.dispose();
                    new MessManager();
                    //System.out.println("yes22");
                }
                else if(uname.equals("admin"))
                {
                    f1.dispose();
                    new Admin();
                }
                else
                {
                    //System.out.println("Employee");
                    //std.setVisible(false);
                    //std.setOpaque(false);
                    JOptionPane.showMessageDialog(null, "Student is already logined");
                }
             }
        });
	emp.setBackground(Color.blue);
	Font my1111=new Font("Serif", Font.BOLD, 20);
	emp.setFont(my1111);
        
        
        //f1.add(hm);
        f1.add(std);
        f1.add(emp);
        
        f1.setSize(1380,750);
	f1.setBackground(Color.blue);
	f1.setLayout(null);
        f1.setVisible(true);
	f1.addWindowListener(new WindowAdapter(){
        @Override
	public void windowClosing(WindowEvent we){
		f1.dispose();}
        });
    
    }
    
    public static void main(String[] args) {
       new HMC();   
    }
}

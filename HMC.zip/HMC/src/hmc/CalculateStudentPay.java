/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hmc;

/**
 *
 * @author RGUKT
 */

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.sql.*; 

public class CalculateStudentPay {
    private JFrame f1;
    private JLabel labe,la;
    private JTextField fee;
    private ResultSet rs2;
    private JTable table;
    private double total_fee;
    private double mess_fee;
    CalculateStudentPay(){
    
        f1=new JFrame("calculate");
        f1.setBackground(Color.cyan);
        labe = new JLabel("CALCULATE STUDENT PAY",JLabel.CENTER);
	Font myFont=new Font("Serif", Font.PLAIN, 40);
        labe.setFont(myFont);
	labe.setForeground(Color.DARK_GRAY);
        labe.setBackground(Color.blue);
	labe.setBounds(01,01,1360,100);
        labe.setOpaque(true);
	f1.add(labe);
        
        JButton hm=new JButton("Home");
	hm.setBounds(10,50,130,35);
        hm.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                f1.dispose();
                new HMC();
             }
        });
        labe.add(hm);
        JButton bc=new JButton("Back");
	bc.setBounds(1200,50,130,35);
        bc.addActionListener( new ActionListener(){
            public void actionPerformed(ActionEvent e){
                f1.dispose();
                new HMC();
             }
        });
        labe.add(bc);
        
        
        Font f = new Font("Serif",Font.PLAIN,25);
        JLabel usrlabel = new JLabel("Fee :");
        usrlabel.setFont(f);
        usrlabel.setBounds(530,120, 200, 50);
        f1.add(usrlabel);
        
        fee = new JTextField();
        fee.setFont(f);
        fee.setBounds(600, 130, 220, 40);
        f1.add(fee);
        
        JButton comp=new JButton("CalculatePay");
	comp.setBounds(600,200,130,35);
        comp.addActionListener( new ActionListener(){
        public void actionPerformed(ActionEvent e){
           if(validate())
           { 
                JFrame f2=new JFrame("HMC/Warden/ViewStudents");
                JPanel  contentPane = new JPanel();
                contentPane.setLayout(null);
                f2.setContentPane(contentPane);
                int size=0; 
                String[][] StudentData;
                try
                {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","");
                    String sql="select * from pay";
                    PreparedStatement ps = con.prepareStatement(sql);  
                    Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                    rs2=ps.executeQuery();
                    if(rs2.last())
                    {
                        size = rs2.getRow();
                        rs2.beforeFirst();
                    }
                    //System.out.println(size);
                }catch(Exception ex)
                {
                    System.out.println(ex);
                }
                StudentData = new String[size][2];    
                int k=0;
                try{

                    while(rs2.next())
                    {
                        String username = rs2.getString(1);
                        StudentData[k][0] = username;    //usernames
                        Double amt = calculateStudentPay(username);
                        total_fee += amt;
                        StudentData[k][1] = Double.toString(amt); //studentpay
                        if(updatePayDataBase(username,amt))
                            k++;
                    }
                }catch(Exception ex)
                {
                    System.out.println(ex);
                }                    
                String[] columnNames = {"Name","Student Fee"};

                table = new JTable(StudentData, columnNames);
                table.setDefaultEditor(Object.class, null);
                JScrollPane scrollPane = new JScrollPane(table);
                table.setFillsViewportHeight(true);

                f2.getContentPane().setLayout(new BorderLayout());
                f2.getContentPane().add(scrollPane,BorderLayout.CENTER);
                f2.setBounds(400, 200, 700, 250);
                f2.setVisible(true);
                
                JOptionPane.showMessageDialog(null,"Total Amount: "+total_fee);
            }
        }
        });
        f1.add(comp);
        f1.setSize(1380,750);
	f1.setBackground(Color.blue);
	f1.setLayout(null);
        f1.setVisible(true);
	f1.addWindowListener(new WindowAdapter(){
        @Override
	public void windowClosing(WindowEvent we){
		f1.dispose();}
        });
        
    }
    
    private boolean updatePayDataBase(String uname,double amt)
    {
        boolean flag = false;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","");
            String sql = "update pay set studentpay='"+amt+"',studentpaystatus=0 WHERE username = '"+uname+"'";
            PreparedStatement ps = con.prepareStatement(sql);   
            int rs = ps.executeUpdate();
            if(rs>0)
                flag = true;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return flag;
    }
    
    private double calculateStudentPay(String uname)
    {
        double total_amt = 0;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root","");
            String sql = "select price from playingroombooking WHERE username = '"+uname+"'";
            PreparedStatement ps = con.prepareStatement(sql);   
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                total_amt+= rs.getDouble(1);
            }
            
            sql = "select price from readingroombooking WHERE username = '"+uname+"'";
            ps = con.prepareStatement(sql);   
            rs = ps.executeQuery();
            while(rs.next())
            {
                total_amt+= rs.getDouble(1);
            }
            
            sql = "select price from tvroombooking WHERE username = '"+uname+"'";
            ps = con.prepareStatement(sql);   
            rs = ps.executeQuery();
            while(rs.next())
            {
                total_amt+= rs.getDouble(1);
            }
            
            total_amt += mess_fee;
        }
        catch(Exception ex)
        {
            System.out.println(ex);
        }
        return total_amt;
    }
    
    private boolean validate(){
        String string_regex = "^[a-zA-Z]+$";
        String mess = fee.getText();

        try
        {
            mess_fee = Double.parseDouble(fee.getText());
            if(mess.matches(string_regex))
            {
                JOptionPane.showMessageDialog(null,"It should be Number","wrong",JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if(mess_fee<100 || mess_fee >3000){
                
                JOptionPane.showMessageDialog(null,"Amount Between 100 and 3000","Wrong",JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }catch(Exception E)
        {
         JOptionPane.showMessageDialog(null,"Enter Valid Amount","Wrong",JOptionPane.WARNING_MESSAGE);
         return false;
        }
        return true;
    } 
    
    public static void main(String args[]){
    
        new CalculateStudentPay();
    }
}
